

function Task1(){

    const fruits =[
        {id:1, name:"Apple"},
        {id:2, name:"Banana"},
        {id:3, name:"Strawberry"}
      ];

    return(
        <>

{fruits.map((v)=>{
         return(
           <b>
            <h2>count</h2>

            <table border={2}>
                <tr>
                    <td>{v.id}</td>
                    <td>{v.name}</td>
                </tr>
            </table>

       
           </b>
         )
      })}
        
        </>
    )
}

export default Task1