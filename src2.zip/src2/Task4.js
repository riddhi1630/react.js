import { useEffect, useState } from "react"

function Task4(){


    const [trivedi,setTrivedi]=useState([])

    useEffect(()=>{
        fetch('https://jsonplaceholder.typicode.com/albums')
        .then((res)=>{return res.json()})
        .then((d)=>{
            // console.log(d)
            setTrivedi(d)
        
           })
            
            
    },[])
    return(
        <>
        <h2>Use Effect</h2>
        {trivedi.map((v)=>(
            <li style={{padding:"20px o",marginRight:"30px"}} key={v.id}>
                {v.id}{""}
                {v.userId}{""}
                {v.title}

            </li>
           
        ))

        }


        </>
    )
}

export default Task4