import { useState } from "react"

function Task3(){


    const [count,setCount ]=useState(0)

    
    return(
        <div>
            <h2>useState</h2>
            <p style={{fontSize:"30px",fontWeight:"bold"}}>{count}</p>
            <button onClick={()=>{setCount(count + 1)}} style={{marginRight:"20px"}}>+</button>
            <button onClick={()=>{setCount(count-1)}}>-</button>
        </div>
    )
}

export default Task3